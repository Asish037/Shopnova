import React, {useState, useEffect, useContext} from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Image,
  ActivityIndicator,
  Platform,
  Alert,
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import {SafeAreaView} from 'react-native-safe-area-context';
import {useNavigation} from '@react-navigation/native';
import { CartContext } from '../Context/CartContext';
import WishlistCard from '../Components/WishlistCard';
import WishlistSkeleton from '../Components/WishlistSkeleton.jsx';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from '../Components/axios';
import { verticalScale } from '../PixelRatio';
import { PADDING } from '../Constant/Padding';
import AppLoader from '../Components/AppLoader';

const MyWishList = () => {
  const [products, setProducts] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [filteredProducts, setFilteredProducts] = useState([]);
  const navigation = useNavigation();
  const { user, token, removeFromWishlist: removeFromWishlistContext } = useContext(CartContext);

  // Functions for WishlistCard
  const handleProductDetails = (item) => {
    console.log('Navigate to product details:', item.id);
    navigation.navigate('PRODUCT_DETAILS', { productId: item.productId || item.id });
  };

  const toggleFavorite = (item) => {
    console.log('Toggle favorite:', item.id);
    // This will be handled by the WishlistCard component
  };

  const removeFromWishlist = (item) => {
    console.log('Remove from wishlist:', item.id);

    if (removeFromWishlistContext) {
      removeFromWishlistContext(item.productId || item.id);
    }

    // Call API to remove from backend
    fetchRemoveLikeProducts(user.id, item.productId || item.id);

    // Update local state immediately for responsiveness
    setProducts(prev => prev.filter(prod => prod.id !== item.id));
    setFilteredProducts(prev => prev.filter(prod => prod.id !== item.id));
  };



  const normalizeWishlistItems = (wishlistItems = []) => {
    console.log('Normalizing items:', wishlistItems.length);
    return wishlistItems.map(prod => ({
      id: prod.wishlist_id,
      productId: prod.productId,
      title: prod.product_name,
      image: prod.product_image,
      offer_price: prod.product_offer_price || prod.product_price,
      price: prod.product_price || prod.product_price,
      description: prod.product_description,
      sku: prod.product_sku,
      isFavorite: true,
    }));
  };

  const fetchLikeProducts = async (userId) => {
    try {
      console.log(`Fetching wishlist for userId: ${userId}`);
      setIsLoading(true);
      
      const token = await AsyncStorage.getItem('userToken');
      if (!token) {
        console.log('No token found');
        setIsLoading(false);
        return;
      }

      const response = await axios({
        method: 'get',
        url: `/get-wishlist?userId=${userId}`,
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        timeout: 10000,
      });

      console.log('API Response:', response.data);

      if (response.data?.data?.wishlist_items) {
        const items = normalizeWishlistItems(response.data.data.wishlist_items);
        console.log('Setting products:', items);
        setProducts(items);
        setFilteredProducts(items);
      } else {
        console.log('No wishlist items found');
        setProducts([]);
        setFilteredProducts([]);
      }
    } catch (error) {
      console.error('Error fetching wishlist:', error);
      setProducts([]);
      setFilteredProducts([]);
    } finally {
      setIsLoading(false);
    }
  };


  useEffect(() => {
    console.log('MyWishList useEffect - User:', user?.id);
    if (user?.id) {
      fetchLikeProducts(user.id);
    }
  }, [user]);

  /** Remove product from wishlist */
  const fetchRemoveLikeProducts = async (userId, productId) => {
    try {
      const token = await AsyncStorage.getItem('userToken');
      if (!token) {
        Alert.alert('Error', 'No auth token found. Please log in again.');
        return;
      }

      // const payload = {
      //   userId: String(userId),
      //   productId: String(productId),
      // };

      const response = await axios({
        method: 'delete',
        url: `/remove-wishlist?userId=${userId}&productId=${productId}`,
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        // data: payload,
      });

      console.log('Wishlist Remove Response:', response.data);
    } catch (error) {
      console.error('Error in fetchRemoveLikeProducts:', error.response?.data || error.message);
    }
  };

  if (isLoading) {
    return (
      <SafeAreaView style={styles.safeArea}>
        <LinearGradient
          colors={['#f54a00', '#F99266']}
          start={{x: 0, y: 0}}
          end={{x: 1, y: 0}}
          style={styles.header}
        >
          <TouchableOpacity onPress={() => navigation.goBack()}>
            <Text style={styles.backButton}>← Back</Text>
          </TouchableOpacity>
          <View style={styles.titleContainer}>
            <Image 
              source={require('../assets/favoriteFilled.png')} 
              style={styles.headerIcon}
            />
            <Text style={styles.title}>My Wishlist</Text>
          </View>
          <View style={styles.placeholder} />
        </LinearGradient>
        
        <View style={styles.skeletonContainer}>
          <FlatList
            data={[1, 2, 3, 4, 5, 6]} // Show 6 skeleton cards
            numColumns={2}
            keyExtractor={(item) => item.toString()}
            renderItem={() => <WishlistSkeleton />}
            showsVerticalScrollIndicator={false}
            style={styles.flatList}
          />
        </View>
      </SafeAreaView>
    );
  }

  if (filteredProducts.length === 0) {
    return (
      <SafeAreaView style={styles.safeArea}>
        <LinearGradient
          colors={['#f54a00', '#F99266']}
          start={{x: 0, y: 0}}
          end={{x: 1, y: 0}}
          style={styles.header}
        >
          <TouchableOpacity onPress={() => navigation.goBack()}>
            <Text style={styles.backButton}>← Back</Text>
          </TouchableOpacity>
          <View style={styles.titleContainer}>
            <Image 
              source={require('../assets/favoriteFilled.png')} 
              style={styles.headerIcon}
            />
            <Text style={styles.title}>My Wishlist</Text>
          </View>
          <View style={styles.placeholder} />
        </LinearGradient>
        
        <View style={styles.emptyContainer}>
          <View style={styles.emptyIconContainer}>
            <Text style={styles.emptyIcon}>💝</Text>
          </View>
          <Text style={styles.emptyTitle}>Your wishlist is empty</Text>
          <Text style={styles.emptySubtitle}>
            Start adding items you love to your wishlist and they'll appear here
          </Text>
          <TouchableOpacity 
            style={styles.exploreButton}
            onPress={() => navigation.navigate('HOME')}
          >
            <Text style={styles.exploreButtonText}>Explore Products</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.container}>
        <LinearGradient
          colors={['#f54a00', '#F99266']}
          start={{x: 0, y: 0}}
          end={{x: 1, y: 0}}
          style={styles.header}
        >
          <TouchableOpacity onPress={() => navigation.goBack()}>
            <Text style={styles.backButton}>← Back</Text>
          </TouchableOpacity>
          <View style={styles.titleContainer}>
            <Image 
              source={require('../assets/favoriteFilled.png')} 
              style={styles.headerIcon}
            />
            <Text style={styles.title}>My Wishlist</Text>
          </View>
          <View style={styles.placeholder} />
        </LinearGradient>
        
        <View style={styles.itemCountContainer}>
          <Text style={styles.itemCount}>
            💖 {filteredProducts.length} {filteredProducts.length === 1 ? 'item' : 'items'} in your wishlist
          </Text>
        </View>
        
        <FlatList
          data={filteredProducts}
          numColumns={2}
          keyExtractor={(item) => item.id.toString()}
          renderItem={({item, index}) => {
            console.log(`Rendering item ${index}:`, item.title);
            return (
              <WishlistCard
                item={item}
                handleProductClick={handleProductDetails}
                toggleFavorite={toggleFavorite}
                removeFromWishlist={removeFromWishlist}
              />
            );
          }}
          showsVerticalScrollIndicator={false}
          style={styles.flatList}
          contentContainerStyle={styles.flatListContent}
          columnWrapperStyle={styles.row}
        />
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  container: {
    flex: 1,
    backgroundColor: '#F8F9FA',
  },
  loaderContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
  },
  loaderText: {
    marginTop: 10,
    fontSize: 16,
    color: '#666666',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 40,
    paddingVertical: 60,
  },
  emptyIconContainer: {
    width: 140,
    height: 140,
    borderRadius: 70,
    backgroundColor: '#FFF5F0',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 32,
    elevation: 8,
    shadowColor: '#f54a00',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.15,
    shadowRadius: 8,
  },
  emptyIcon: {
    fontSize: 56,
  },
  emptyTitle: {
    fontSize: 26,
    fontWeight: 'bold',
    color: '#2C2C2C',
    marginBottom: 16,
    textAlign: 'center',
  },
  emptySubtitle: {
    fontSize: 17,
    color: '#666666',
    textAlign: 'center',
    lineHeight: 26,
    marginBottom: 40,
  },
  exploreButton: {
    backgroundColor: '#f54a00',
    paddingHorizontal: 32,
    paddingVertical: 16,
    borderRadius: 25,
    elevation: 4,
    shadowColor: '#f54a00',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
  },
  exploreButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: PADDING.content.horizontal,
    paddingVertical: PADDING.content.vertical,
    paddingTop: PADDING.margin.large,
    paddingBottom: PADDING.margin.xlarge,
    minHeight: 80,
    elevation: 4,
    shadowColor: '#f54a00',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.15,
    shadowRadius: 4,
  },
  backButton: {
    fontSize: 16,
    color: '#FFFFFF',
    fontWeight: '600',
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 8,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
  },
  titleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerIcon: {
    width: 24,
    height: 24,
    marginRight: 8,
    tintColor: '#FFFFFF',
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FFFFFF',
    textShadowColor: 'rgba(0, 0, 0, 0.1)',
    textShadowOffset: {width: 0, height: 1},
    textShadowRadius: 2,
  },
  placeholder: {
    width: 50,
  },
  itemCountContainer: {
    backgroundColor: '#FFF5F0',
    marginHorizontal: PADDING.content.horizontal,
    marginVertical: PADDING.margin.medium,
    borderRadius: 12,
    paddingVertical: PADDING.margin.medium,
    paddingHorizontal: PADDING.content.horizontal,
    elevation: 2,
    shadowColor: '#f54a00',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  itemCount: {
    fontSize: 16,
    color: '#f54a00',
    fontWeight: '600',
    textAlign: 'center',
  },
  flatList: {
    flex: 1,
    backgroundColor: '#F8F9FA',
  },
  flatListContent: {
    paddingHorizontal: PADDING.flatList.horizontal,
    paddingTop: PADDING.margin.medium,
    paddingBottom: PADDING.margin.xlarge,
  },
  row: {
    justifyContent: 'space-between',
  },
  skeletonContainer: {
    flex: 1,
    backgroundColor: '#F8F9FA',
  },
});

export default MyWishList;