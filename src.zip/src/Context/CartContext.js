import AsyncStorage from '@react-native-async-storage/async-storage';
import {createContext, useEffect, useState, useContext} from 'react';
import {Text} from 'react-native';
import AppLoader from '../Components/AppLoader';

export const CartContext = createContext();

export const CartProvider = ({children}) => {
  const [cartItems, setCartItems] = useState([]);
  const [totalPrice, setTotalPrice] = useState(0);

  const [user, setUser] = useState(null);
  const [token, setToken] = useState(null);
  const [messages, setMessages] = useState({});
  const [isLoading, setIsLoading] = useState(true);
  const [wishlist, setWishlist] = useState([]);

  useEffect(() => {
    const loadData = async () => {
      await loadAuthData();
      await loadMessages();
      await loadCartItems();
      setIsLoading(false);
    };

    loadData();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const loadAuthData = async () => {
    try {
      console.log('Loading auth data from AsyncStorage...');
      const [userData, storedToken] = await AsyncStorage.multiGet([
        'userData',
        'userToken',
      ]);

      console.log('Loaded userData:', userData[1]);
      console.log('Loaded token:', storedToken[1]);

      if (userData[1]) {
        const parsedUser = JSON.parse(userData[1]);
        setUser(parsedUser);
        console.log('User data set in state:', parsedUser);
      }

      if (storedToken[1]) {
        setToken(storedToken[1]);
        console.log('Token set in state:', storedToken[1]);
      }

      console.log('Auth data loading completed');
    } catch (error) {
      console.error('Error loading auth data:', error);
    }
  };

  const loadMessages = async () => {
    try {
      const storedMessages = await AsyncStorage.getItem('messages');
      if (storedMessages) {
        setMessages(JSON.parse(storedMessages));
      }
    } catch (error) {
      console.error('Error loading messages:', error);
    }
  };

  const login = async (userData, authToken = null) => {
    console.log('login called with userData:', userData);
    console.log('login called with authToken:', authToken);

    try {
      // First save to AsyncStorage
      await AsyncStorage.setItem('userData', JSON.stringify(userData));
      console.log('User data saved to AsyncStorage');

      if (authToken) {
        console.log('Saving token to AsyncStorage:', authToken);
        await AsyncStorage.setItem('userToken', authToken);
        console.log('Token saved to AsyncStorage');
      }

      // Then update React state
      setUser(userData);
      if (authToken) {
        setToken(authToken);
        console.log('Token set in React state');
      }

      console.log('Login completed successfully');
    } catch (error) {
      console.error('Error in login function:', error);
    }
  };

  const setAuthToken = async authToken => {
    console.log('setAuthToken called with:', authToken);
    try {
      // First save to AsyncStorage
      await AsyncStorage.setItem('userToken', authToken);
      console.log('Token saved to AsyncStorage successfully');

      // Then update React state
      setToken(authToken);
      console.log('Token set in React state');

      // Verify it was saved
      const savedToken = await AsyncStorage.getItem('userToken');
      console.log('Verification - saved token:', savedToken);
    } catch (error) {
      console.error('Error saving token:', error);
    }
  };

  const updateProfileImage = async imageBase64 => {
    try {
      // Update state
      setUser(prev => {
        const updatedUser = {...prev, profileImage: imageBase64};

        // Save to AsyncStorage
        AsyncStorage.setItem('userData', JSON.stringify(updatedUser));
        return updatedUser;
      });
    } catch (error) {
      console.error('Error updating profile image:', error);
    }
  };

  const logout = async () => {
    setUser(null);
    setToken(null);
    try {
      await AsyncStorage.removeItem('userData');
      await AsyncStorage.removeItem('userToken');
    } catch (error) {
      console.error('Error removing user data:', error);
    }
  };

  const addToWishlist = item => {
    console.log('Adding to wishlist:', item);
    setWishlist(prev => {
      const newWishlist = [...(prev || []), item];
      console.log('Updated wishlist:', newWishlist);
      return newWishlist;
    });
  };

  const removeFromWishlist = productId => {
    console.log('Removing from wishlist, productId:', productId);
    setWishlist(prev => {
      const newWishlist = (prev || []).filter(prod => {
        // Check both id and productId fields
        const prodId = prod.id || prod.productId;
        return prodId !== productId;
      });
      console.log('Updated wishlist after removal:', newWishlist);
      return newWishlist;
    });
  };

  const isFavorite = productId => {
    const result =
      wishlist?.some(prod => {
        // Check both id and productId fields
        const prodId = prod.id || prod.productId;
        return prodId === productId;
      }) || false;
    console.log(
      'Checking if favorite, productId:',
      productId,
      'result:',
      result,
      'wishlist:',
      wishlist,
    );
    return result;
  };

  const saveMessage = async (roomName, messageData) => {
    const updatedMessages = {
      ...messages,
      [roomName]: [...(messages[roomName] || []), messageData],
    };
    setMessages(updatedMessages);
    try {
      await AsyncStorage.setItem('messages', JSON.stringify(updatedMessages));
    } catch (error) {
      console.error('Error saving messages:', error);
    }
  };

  const loadCartItems = async () => {
    try {
      let cartItems = await AsyncStorage.getItem('cart');
      cartItems = cartItems ? JSON.parse(cartItems) : [];
      console.log(
        'loadCartItems - Loaded from AsyncStorage:',
        cartItems.length,
        'items',
      );

      // Ensure all items have a quantity property
      cartItems = cartItems.map(item => ({
        ...item,
        quantity: item.quantity || 1,
      }));

      setCartItems(cartItems);
      calculateTotalPrice(cartItems);

      // Save back to AsyncStorage with quantity property
      await AsyncStorage.setItem('cart', JSON.stringify(cartItems));
      console.log('loadCartItems - Set cart items:', cartItems.length);
    } catch (error) {
      console.error('Error loading cart items:', error);
      setCartItems([]);
      calculateTotalPrice([]);
      // Optionally, you can set an error state here if needed
    }
  };

  const addToCartItem = async item => {
    console.log('Adding item to cart:', item);
    let cartItems = await AsyncStorage.getItem('cart');
    cartItems = cartItems ? JSON.parse(cartItems) : [];

    // Only add items with a valid productId
    const productId = item.productId || item.id || item.product_id;
    if (!productId) {
      console.warn('Attempted to add item without a valid productId:', item);
      return;
    }

    let isExist = cartItems.findIndex(cart => {
      const cartProductId = cart.productId || cart.id || cart.product_id;
      return cartProductId === productId;
    });

    if (isExist === -1) {
      // Always set productId and id fields
      const itemToAdd = {
        ...item,
        productId: productId,
        id: productId,
        quantity: 1,
      };
      cartItems.push(itemToAdd);
      calculateTotalPrice(cartItems);
      setCartItems(cartItems);
      await AsyncStorage.setItem('cart', JSON.stringify(cartItems));
    }
  };

  const deleteCartItem = async id => {
    let cartItems = await AsyncStorage.getItem('cart');
    cartItems = cartItems ? JSON.parse(cartItems) : [];
    cartItems = cartItems.filter(item => item.id !== id);
    setCartItems(cartItems);
    calculateTotalPrice(cartItems);
    await AsyncStorage.setItem('cart', JSON.stringify(cartItems));
  };

  const updateCartItemQuantity = async (id, newQuantity) => {
    if (newQuantity < 1) return;

    let cartItems = await AsyncStorage.getItem('cart');
    cartItems = cartItems ? JSON.parse(cartItems) : [];

    const updatedCartItems = cartItems.map(item =>
      item.id === id ? {...item, quantity: newQuantity} : item,
    );

    setCartItems(updatedCartItems);
    calculateTotalPrice(updatedCartItems);
    await AsyncStorage.setItem('cart', JSON.stringify(updatedCartItems));
  };

  const clearCart = async () => {
    console.log('Clearing cart...');
    console.log('Cart items before clearing:', cartItems.length);

    try {
      // Clear AsyncStorage first
      await AsyncStorage.removeItem('cart');
      console.log('Cart cleared successfully from AsyncStorage');

      // Then update React state
      setCartItems([]);
      setTotalPrice('0.00');

      console.log('Cart state updated - items should now be 0');
    } catch (error) {
      console.error('Error clearing cart:', error);
    }
  };

  const calculateTotalPrice = cartItems => {
    let totalSum = cartItems.reduce((total, item) => {
      // Convert offer_price to a floating-point number, check both field names
      const offerPrice = parseFloat(item.offer_price || item.offerPrice);
      const quantity = item.quantity || 1;
      // Check if offerPrice is a valid number before multiplying
      if (!isNaN(offerPrice)) {
        return total + offerPrice * quantity;
      }

      // Return the current total if the offerPrice is invalid
      return total;
    }, 0);

    // After the loop, check if the final total is a valid number
    if (!isNaN(totalSum)) {
      totalSum = totalSum.toFixed(2);
      setTotalPrice(totalSum);
    } else {
      setTotalPrice('0.00'); // Set to a default value if the total is NaN
    }
  };

  if (isLoading) {
    return <AppLoader message="Loading your data..." />;
  }

  const getTotalQuantity = () => {
    const total = cartItems.reduce(
      (total, item) => total + (item.quantity || 1),
      0,
    );
    console.log(
      'getTotalQuantity - Cart items:',
      cartItems.length,
      'Total quantity:',
      total,
    );
    return total;
  };

  const value = {
    cartItems,
    addToCartItem,
    deleteCartItem,
    updateCartItemQuantity,
    clearCart,
    loadCartItems,
    totalPrice,
    getTotalQuantity,
    user,
    token,
    login,
    logout,
    setAuthToken,
    updateProfileImage,
    loadAuthData,
    saveMessage,
    messages,
    wishlist,
    addToWishlist,
    removeFromWishlist,
    isFavorite,
  };
  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
};

const HotelContext = createContext();

export const HotelProvider = ({children}) => {
  const [hotelData, setHotelData] = useState({});

  const updateHotelData = newData => {
    setHotelData(prevData => ({...prevData, ...newData}));
  };

  return (
    <HotelContext.Provider value={{hotelData, updateHotelData}}>
      {children}
    </HotelContext.Provider>
  );
};

export const useHotel = () => {
  const context = useContext(HotelContext);
  if (context === undefined) {
    throw new Error('useHotel must be used within a HotelProvider');
  }
  return context;
};
